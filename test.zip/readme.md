To start this application locally,
Run the following command in terminal

 -- npm start