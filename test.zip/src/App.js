// import statements
import "./styles.css";
import React, { useState } from "react";
export default function App() {

  // create state variables using useState imported from react
  const [value, updateValue] = useState();
  const [arrayValues, updateArrayValues] = useState([]);
  const [result, updateResult] = useState("");

  // trigger onChange when user enters the values inside the text inputs
  const onChange = (value, key) => {
    arrayValues[key] = value;
    // update the array
    updateArrayValues(arrayValues);
  };

  // update the value and array when user enters a number 
  const updateValues = (value) => {
    updateValue(value);
    // update the array with empty values so that we can use this array in looping and rendering the input field for the user to enter values
    for (var i = 0; i < value; i++) {
      arrayValues.push("");
    }
    // update the array 
    updateArrayValues(arrayValues);
  };

  // updates the result in ascending order when Ascending button is clicked
  const arrangeInAscending = () => {
    updateResult(arrayValues.sort());
  };

  //updates the result in descending order when Descending button is clicked
  const arrangeInDescending = () => {
    const res = arrayValues.sort();
    updateResult(res.reverse());
  };

  // this is the return statement which renders the input fields
  return (
    <div>
      <label> Enter a number:</label>
      <input type="number" onChange={(e) => updateValues(e.target.value)} />
      <div>
        {value && <div class="numberInputs">
          {" "}
          Enter the list of numbers you want to sort{" "}
        </div>
        }
        {value &&
          arrayValues.length > 0 &&
          arrayValues?.map((val, key) => (
            <input
              class="input"
              key={key}
              type="number"
              onChange={(e) => onChange(e.target.value, key)}
            />
          ))}
      </div>
      {value && (
        <div class="order">
          <button onClick={() => arrangeInAscending()}> Ascending </button>
          <button onClick={() => arrangeInDescending()}> Descending </button>
        </div>
      )}
      {result && <div> {result.toString()}</div>}
    </div>
  );
}
