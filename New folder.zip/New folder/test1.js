let unsorted = [];

function onSubmit() {
    unsorted.push(document.getElementById("input").value);
    document.getElementById('textoutput').innerHTML = unsorted;
    document.getElementById('input').value = '';
}

function onClickAscSort() {
    const strAscSort = unsorted.sort();
    const ascsorted = strAscSort.sort(function(a, b){return a - b});
    document.getElementById('ascsortedoutput').innerHTML = ascsorted;
}

function onClickDesSort() {
    const strSort = unsorted.reverse();
    const dessorted = strSort.sort(function(a, b){return b - a});
    document.getElementById('dessortedoutput').innerHTML = dessorted;
}